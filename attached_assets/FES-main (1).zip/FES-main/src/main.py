"""Main entry point for the FES application."""

import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from gui import FESApp

def main() -> None:
    """Initialize and run the main application."""
    os.environ["QT_QPA_PLATFORM"] = "webgl"
    os.environ["QT_DEBUG_PLUGINS"] = "1"
    os.environ["DISPLAY"] = ":99"
    os.environ["QT_QPA_FONTDIR"] = "/usr/share/fonts"
    os.environ["XDG_RUNTIME_DIR"] = "/tmp/runtime-runner"
    os.environ["FONTCONFIG_PATH"] = "/etc/fonts"
    
    app = QApplication(sys.argv)
    window = FESApp()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()