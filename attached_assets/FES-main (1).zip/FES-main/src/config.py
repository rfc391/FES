
import os

# Email Configuration
EMAIL_USER = os.getenv('EMAIL_USER', '')
EMAIL_PASS = os.getenv('EMAIL_PASS', '')
EMAIL_RECIPIENT = os.getenv('EMAIL_RECIPIENT', '')

# Webhook Configuration
WEBHOOK_URL = os.getenv('WEBHOOK_URL', '')

# Cloudflare Configuration
CLOUDFLARE_ZONE_ID = os.getenv('CLOUDFLARE_ZONE_ID', '')
CLOUDFLARE_HEADERS = {
    'Authorization': f"Bearer {os.getenv('CLOUDFLARE_API_TOKEN', '')}",
    'Content-Type': 'application/json'
}
