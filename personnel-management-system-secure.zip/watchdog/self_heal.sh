
#!/bin/bash

APP_PATH="/opt/personnel-management-system/core/main.py"
LOG_PATH="/var/log/personnel_watchdog.log"

if ! pgrep -f "$APP_PATH" > /dev/null
then
    echo "$(date): Restarting personnel-management-system" >> $LOG_PATH
    nohup python3 $APP_PATH &
fi
