
import os
from flask import Flask, jsonify, request, render_template, redirect
from modules.role_access.auth import verify_user_role, stealth_check
from modules.gpg_secure.unlock import gpg_unlock_check
from modules.gpg_secure.dropzone_encryptor import encrypt_file_gpg
from modules.ai_recon.llm_tools import run_sentiment_analysis
from modules.surveillance.camera_monitor import take_snapshot

app = Flask(__name__, template_folder="../dashboard/templates")

if not gpg_unlock_check():
    print("[!] GPG Unlock Failed. System Locked.")
    exit(1)

@app.route("/")
def home():
    role = request.args.get("role", "guest")
    if stealth_check(role):
        return render_template("dummy.html")
    if verify_user_role(role):
        return render_template(f"{role}.html")
    return "Unauthorized", 403

@app.route("/status")
def status():
    return jsonify({"status": "Online", "ip": "2a02:c7c:7eb9:e200:465e:fa3e:75c8:83eb"})

@app.route("/recon", methods=["POST", "GET"])
def recon():
    text = request.args.get("text", "Operational update required.")
    result = run_sentiment_analysis(text)
    return jsonify({"recon_result": result})

@app.route("/snapshot")
def snapshot():
    path = take_snapshot()
    return jsonify({"snapshot": path})

@app.route("/encrypt_dropzone")
def encrypt_dropzone():
    files = os.listdir("dropzone/")
    encrypted = []
    for f in files:
        if not f.endswith(".gpg"):
            result = encrypt_file_gpg(f)
            if result:
                encrypted.append(result)
    return jsonify({"encrypted_files": encrypted})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5006)
