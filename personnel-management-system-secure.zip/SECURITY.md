# Security Policy

- **Report vulnerabilities** via [security@apexsecurityint.com](mailto:security@apexsecurityint.com)
- Ensure security patches are applied regularly.
