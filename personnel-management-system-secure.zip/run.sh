#!/bin/bash
echo "Starting personnel-management-system system..."
python3 main.py
