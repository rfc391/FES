
#!/bin/bash
echo "[+] Starting full installation of Personnel Management System"

# Update system and install dependencies
sudo apt update && sudo apt install -y python3 python3-pip python3-venv ffmpeg libopencv-dev gpg

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install flask transformers pandas cryptography opencv-python whisper

# Create folders if missing
mkdir -p dropzone/encrypted assets

# GPG Key Trust Setup (optional: should already be configured)
echo "[*] GPG Key assumed to be imported and trusted"

# Enable watchdog via cron (fallback method)
(crontab -l 2>/dev/null; echo "*/2 * * * * $(pwd)/watchdog/self_heal.sh") | crontab -

# Run the app
echo "[+] Launching secure server..."
python3 core/main.py
