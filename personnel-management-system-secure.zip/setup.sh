#!/bin/bash
echo "Setting up personnel-management-system..."
pip install -r requirements.txt
chmod +x run.sh
