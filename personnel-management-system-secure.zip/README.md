# Personnel Management System

## 🧠 Overview
A secure, cross-platform personnel management system designed for high-performance environments such as emergency response, security teams, or distributed field ops.

## ⚙️ Features
- Role & permission-based user system
- Secure offline support
- Audit-ready logging
- Cross-platform support (Linux, Windows, Mac)
- Installer support: `.deb`, `.exe`, `.AppImage`
- CI/CD with GitHub Actions
- GUI & CLI modes
- Built-in testing & diagnostics

## 🚀 Setup Instructions

### 🐧 Linux / 🖥 macOS
```bash
git clone https://github.com/paracryptid/personnel-management-system.git
cd personnel-management-system
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python app.py
```

### 🪟 Windows
```powershell
git clone https://github.com/paracryptid/personnel-management-system.git
cd personnel-management-system
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## 📦 Cross-Platform Builds
| Platform | Format     |
|----------|------------|
| Linux    | `.deb`, `.AppImage` |
| Windows  | `.exe`     |
| macOS    | `.pkg` (planned)  |

## 🧪 Testing
```bash
pytest tests/
```

## 🤝 Contributing
Please fork the repo, push to a feature branch, and open a Pull Request. Follow our `docs/contributing.md` guide for standards.

## 🛡 Security
- Offline encrypted data handling
- System audit logs
- User authentication layers
- Optional remote webhook trigger

## 🖼 UI Preview
*(Coming soon – GIF & screenshots of interface in action)*

## 📜 License
MIT License — see LICENSE file for details.
