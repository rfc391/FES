
def verify_user_role(role):
    return role in ["admin", "agent"]

def stealth_check(role):
    return role == "stealth"
