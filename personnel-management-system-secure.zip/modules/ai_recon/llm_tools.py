
from transformers import pipeline

def run_sentiment_analysis(text):
    try:
        classifier = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english")
        return classifier(text)
    except Exception as e:
        return [{"error": str(e)}]
