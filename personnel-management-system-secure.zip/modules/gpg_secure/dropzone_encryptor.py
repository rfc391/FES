
import subprocess
import os

DROPZONE_PATH = "dropzone/"
ENCRYPTED_PATH = "dropzone/encrypted/"

os.makedirs(ENCRYPTED_PATH, exist_ok=True)

def encrypt_file_gpg(filename):
    input_path = os.path.join(DROPZONE_PATH, filename)
    output_path = os.path.join(ENCRYPTED_PATH, f"{filename}.gpg")

    try:
        subprocess.run([
            "gpg", "--yes", "--batch", "--trust-model", "always",
            "--output", output_path,
            "--encrypt", "--recipient", "System Unlock <tactical@localhost>",
            input_path
        ], check=True)
        return output_path
    except subprocess.CalledProcessError:
        return None
