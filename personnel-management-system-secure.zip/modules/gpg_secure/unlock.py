
import subprocess

def gpg_unlock_check():
    try:
        result = subprocess.run([
            'gpg', '--batch', '--yes', '--decrypt',
            '--recipient', 'System Unlock <tactical@localhost>',
            '--output', '/dev/null',
            '--quiet', '--no-tty',
            'modules/gpg_secure/unlock_test.gpg'
        ], check=True)
        return True
    except subprocess.CalledProcessError:
        return False
