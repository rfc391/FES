
import cv2

def monitor_camera(duration=10):
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        return "Camera not accessible"

    frames = []
    for _ in range(int(duration * 10)):
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)
        cv2.imshow('Surveillance Feed', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return f"Captured {len(frames)} frames"

def take_snapshot():
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()
    if ret:
        filename = "assets/snapshot.jpg"
        cv2.imwrite(filename, frame)
        return filename
    return "Snapshot failed"
