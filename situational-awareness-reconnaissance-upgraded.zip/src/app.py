from flask import Flask, jsonify, request, render_template
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from transformers import pipeline
import logging
from config import Config

# Initialize Flask app and config
app = Flask(__name__)
app.config.from_object(Config)

# Setup CORS (adjust origins for deployment)
CORS(app, resources={r"/*": {"origins": "*"}})

# Setup SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Setup Logging
logging.basicConfig(
    level=Config.LOG_LEVEL,
    format='%(asctime)s [%(levelname)s] %(message)s',
)

logger = logging.getLogger(__name__)

# Initialize AI model pipeline (NLP)
try:
    reconnaissance_analyzer = pipeline("sentiment-analysis")
    logger.info("AI pipeline initialized successfully.")
except Exception as e:
    logger.error(f"Failed to initialize AI pipeline: {e}")
    reconnaissance_analyzer = None

@app.route('/')
def home():
    return render_template('index.html')
        "message": "Situational Awareness and Reconnaissance system is operational.",
        "version": "1.0.0"
    })

@app.route('/analyze', methods=['POST'])
def analyze_text():
    data = request.get_json()
    text = data.get("text", "")

    if not text:
        return jsonify({"error": "Text input is required."}), 400

    if reconnaissance_analyzer:
        result = reconnaissance_analyzer(text)
        return jsonify({"result": result})
    else:
        return jsonify({"error": "AI pipeline not initialized."}), 500

@app.route('/status')
def status():
    return jsonify({"status": "active", "debug": app.config['DEBUG']})

@app.route('/version')
def version():
    return jsonify({"version": "1.0.0"})

# WebSocket test event
@socketio.on('connect')
def handle_connect():
    logger.info("Client connected.")
    emit("response", {"message": "Connected to server."})

@socketio.on('disconnect')
def handle_disconnect():
    logger.info("Client disconnected.")

if __name__ == '__main__':
    logger.info("Starting Situational Awareness server...")
    socketio.run(app, host='0.0.0.0', port=8080)
