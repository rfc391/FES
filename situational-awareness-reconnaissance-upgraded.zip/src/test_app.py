import unittest
from app import app

class SituationalAwarenessTests(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True

    def test_home(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn("Situational Awareness and Reconnaissance", response.get_json()["message"])

    def test_analyze_text(self):
        payload = {"text": "This is a critical situation."}
        response = self.app.post('/analyze', json=payload)
        self.assertEqual(response.status_code, 200)
        self.assertIn("result", response.get_json())

    def test_analyze_text_empty(self):
        response = self.app.post('/analyze', json={})
        self.assertEqual(response.status_code, 400)
        self.assertIn("error", response.get_json())

    def test_status(self):
        response = self.app.get('/status')
        self.assertEqual(response.status_code, 200)
        self.assertIn("status", response.get_json())

    def test_version(self):
        response = self.app.get('/version')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["version"], "1.0.0")

if __name__ == '__main__':
    unittest.main()
