#!/bin/bash
set -e

APP="situational-recon"
APP_DIR=AppDir

# Clean up
rm -rf $APP_DIR
mkdir -p $APP_DIR/usr/bin

# Copy app
cp ../../src/app.py $APP_DIR/usr/bin/$APP
chmod +x $APP_DIR/usr/bin/$APP

# Create AppRun
cat <<EOF > $APP_DIR/AppRun
#!/bin/bash
exec python3 /usr/bin/$APP
EOF

chmod +x $APP_DIR/AppRun

# Create .desktop file
mkdir -p $APP_DIR/usr/share/applications
cat <<EOF > $APP_DIR/usr/share/applications/$APP.desktop
[Desktop Entry]
Name=Situational Recon
Exec=$APP
Icon=app
Type=Application
Categories=Utility;
EOF

# Package with AppImageTool
appimagetool $APP_DIR
echo ".AppImage created."
