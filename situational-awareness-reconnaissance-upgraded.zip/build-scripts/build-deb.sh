#!/bin/bash
set -e

APP_NAME="situational-recon"
VERSION="1.0.0"
ARCH="all"
BUILD_DIR="build/$APP_NAME"

# Clean old builds
rm -rf $BUILD_DIR
mkdir -p $BUILD_DIR/DEBIAN
mkdir -p $BUILD_DIR/usr/local/bin
mkdir -p $BUILD_DIR/usr/local/share/$APP_NAME

# Copy files
cp -r ../../src/* $BUILD_DIR/usr/local/share/$APP_NAME/
echo -e "#!/bin/bash\npython3 /usr/local/share/$APP_NAME/app.py" > $BUILD_DIR/usr/local/bin/$APP_NAME
chmod +x $BUILD_DIR/usr/local/bin/$APP_NAME

# Control file
cat <<EOF > $BUILD_DIR/DEBIAN/control
Package: $APP_NAME
Version: $VERSION
Section: base
Priority: optional
Architecture: $ARCH
Depends: python3, python3-pip
Maintainer: ParaCryptid
Description: Situational Awareness Reconnaissance Tool
EOF

# Build the .deb package
dpkg-deb --build $BUILD_DIR
mv $BUILD_DIR.deb $APP_NAME-$VERSION.deb
echo "Built $APP_NAME-$VERSION.deb"
