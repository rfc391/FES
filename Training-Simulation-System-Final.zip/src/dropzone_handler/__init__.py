# dropzone_handler module initialized
