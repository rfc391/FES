# sensor_simulation module initialized
