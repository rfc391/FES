# stealth_mode module initialized
