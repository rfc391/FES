# watchdog module initialized
