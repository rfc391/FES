# opencv_surveillance module initialized
