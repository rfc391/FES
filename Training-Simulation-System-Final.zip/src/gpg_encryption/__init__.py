# gpg_encryption module initialized
