#!/bin/bash
echo "Starting training-simulation-system system..."
python3 main.py
