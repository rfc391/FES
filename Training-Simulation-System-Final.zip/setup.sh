#!/bin/bash
echo "Setting up training-simulation-system..."
pip install -r requirements.txt
chmod +x run.sh
